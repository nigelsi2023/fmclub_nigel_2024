@extends('layouts.admin')

@section('content')
<div class="container-fluid">
	
	@if(session('message'))
	<div class="alert alert-success">
		<button type="button" aria-hidden="true" class="close"
		onclick="this.parentElement.style.display='none'">×</button>
		<span>{{ session('message') }}</span>
	</div>
	@endif

	<div class="card mb-3">
		<div class="card-header">
			<i class="fas fa-table"></i>
			Signals
		</div>
		<div class="card-body">
			<div class="table-responsive">
				<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
					<thead>
						<tr>
							<th>SL</th>
							<th>Name</th>
							<th>Email</th>
							<th>Mobile</th>
							<th>Country</th>
							<th>Reference</th>
							<th>Telegram ID</th>
							<!-- <th style="width: 132px;">Action</th> -->
						</tr>
					</thead>
					<tfoot>
						<tr>
							<th>SL</th>
							<th>Name</th>
							<th>Email</th>
							<th>Mobile</th>
							<th>Country</th>
							<th>Reference</th>
							<th>Telegram ID</th>
							<!-- <th style="width: 132px;">Action</th> -->
						</tr>
					</tfoot>

					<tbody>
						@foreach ($registerdUser as $key => $users)
						<tr>
							<td>
							    {{ $key+1 }}
							</td>
							<td>{{ $users->fname }} {{ $users->lname }}</td>
							<td>{{ $users->email }}</td>
							<td>{{ $users->mobile }}</td>
							<td>{{ $users->country }}</td>
							<td>{{ $users->reference }}</td>
							<td>{{ $users->address }}</td>
						</tr>
						@endforeach 
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<!-- /.container-fluid -->


@endsection


