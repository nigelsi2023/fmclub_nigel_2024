@extends('layouts.admin')

@section('content')
<div class="container-fluid">

  <div class="admincreatetitle">
    <h2>Please Enter Signal Informations</h2>
  </div>
  
  

  @if(session('message'))
  <div class="alert alert-success">
    <button type="button" aria-hidden="true" class="close"
    onclick="this.parentElement.style.display='none'">×</button>
    <span>{{ session('message') }}</span>
  </div>
  @endif
  
   @if ($errors->any())
    @foreach ($errors->all() as $error)
      <div class="alert alert-danger">
        <button type="button" aria-hidden="true" class="close"
        onclick="this.parentElement.style.display='none'">×</button>
        <span>{{ $error }}</span>
      </div>
    @endforeach
  @endif

  <div class="card mb-3">
    <div class="card-header">Add Signal Information</div>
    <div class="card-body">
      <form action="{{ route('signal.store') }}" method="post" enctype="multipart/form-data">
      @csrf
      <div class="form-group">
        <label for="email">Stock Item Name<span style="color:red;">*</span>:</label>
        <!--<input type="text" class="form-control" id="item_name" name='name' />-->
        <select id="item_name" name="item_name" class="form-control">
            @if($items)
                @foreach($items as $item)
                <option value ="{{$item->name}}">{{$item->name}}</option>
                @endforeach
            @endif                
        </select>
      </div>
      <div class="form-group">
        <label for="email">Open Price<span style="color:red;">*</span>:</label>
        <input type="number" class="form-control" id="open_price" name='open_price' min="0" step="0.01" />
      </div>
      <div class="form-group">
        <label for="email">Target Price<span style="color:red;">*</span>:</label>
        <input type="number" class="form-control" id="target_price" name='target_price' min="0" step="0.01" />
      </div>
      <div class="form-group">
        <label for="email">Stop Loss<span style="color:red;">*</span>:</label>
        <input type="number" class="form-control" id="stop_loss" name='stop_loss' min="0" step="0.01" />
      </div>
      <div class="form-group">
        <label for="email">Closed Price<span style="color:red;">*</span>:</label>
        <input type="number" class="form-control" id="closed_price" name='closed_price' min="0" step="0.01" />
      </div>
      <button type="submit" class="btn btn-primary">Save</button>
    </form>
  </div>
</div>
</div>

@endsection 


@section('scripts')
<script >

$(document).ready(function () {
  $("#success-alert").fadeTo(2000, 500).slideUp(500, function(){
    $("#success-alert").slideUp(500);
});
});

</script>

@endsection